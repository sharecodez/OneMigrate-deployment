$Info = Get-ComputerInfo
